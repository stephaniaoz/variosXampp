# Generate csv, excel, json and xml with php
Class that generate csv, excel, json and xml from array with php
