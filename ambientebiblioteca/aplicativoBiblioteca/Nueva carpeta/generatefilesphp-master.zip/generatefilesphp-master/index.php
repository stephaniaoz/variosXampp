<html>
    <head>
        <meta charset="utf-8">
    </head>
    <body>
        <a href="download.php?type=csv" target="_blank">CSV</a><br>
        <a href="download.php?type=excel" target="_blank">EXCEL</a><br>
        <a href="download.php?type=json" target="_blank">JSON</a><br>
        <a href="download.php?type=xml" target="_blank">XML</a><br>
    </body>
</html>

