<?php

// Don't redefine the functions if included multiple times.
if (!function_exists('League\Csv\bom_match')) {
    require __DIR__.'/functions.php';
}
